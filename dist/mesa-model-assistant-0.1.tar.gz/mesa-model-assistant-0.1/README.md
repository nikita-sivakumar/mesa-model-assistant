# mesa-model-assistant

## ModelExplorerMP
ModelExploreMP is a helper class created to manage batchruns across multiple cores of agent-based models implemented in mesa. 